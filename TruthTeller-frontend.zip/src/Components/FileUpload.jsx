import React, { useState } from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import CircularProgress from "@mui/material/CircularProgress";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Navbar from './Navbar';

function FileUpload() {
  const [loading, setLoading] = useState(false);
  const [file, setFile] = useState(null);
  const [response, setResponse] = useState(null);
  const [videoUrl, setVideoUrl] = useState(null); // For previewing the video
  const [youtubeLink, setYoutubeLink] = useState(""); // For YouTube link input

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
      setVideoUrl(URL.createObjectURL(selectedFile)); // Generate a temporary URL for preview
    } else {
      setFile(null);
      setVideoUrl(null);
    }
  };

  const handleYouTubeLinkChange = (e) => {
    const link = e.target.value;
    setYoutubeLink(link);

    // Extract the video ID from the YouTube URL and generate the embed link
    const videoId = link.split("v=")[1]?.split("&")[0] || link.split("/").pop();
    if (videoId) {
      setVideoUrl(`https://www.youtube.com/embed/${videoId}`);
    } else {
      setVideoUrl(null);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    if (file && youtubeLink) {
      toast.error("Please provide either a file or a YouTube link, not both.");
      setLoading(false);
      return;
    }

    if (youtubeLink) {
      try {
        const res = await fetch("http://127.0.0.1:5000/predict/link", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ url: youtubeLink }),
        });

        const result = await res.json();

        if (res.ok) {
          setResponse(result);
          toast.success("YouTube link processed successfully!");
        } else {
          toast.error(result.error || "Processing failed. Please try again.");
        }
      } catch (error) {
        toast.error("An error occurred. Please try again.");
      } finally {
        setLoading(false);
      }
    } else if (file) {
      const formData = new FormData();
      formData.append("file", file);

      try {
        const res = await fetch("http://127.0.0.1:5000/predict", {
          method: "POST",
          body: formData,
        });

        const result = await res.json();
         console.log(result);
         
        if (res.ok) {
          setResponse(result); // Save the response to state
          toast.success("File uploaded successfully!");
        } else {
          toast.error(result.error || "File upload failed. Please try again.");
        }
      } catch (error) {
        toast.error("An error occurred. Please try again.");
      } finally {
        setLoading(false);
      }
    } else {
      toast.error("Please provide either a file or a YouTube link.");
      setLoading(false);
    }
  };

  return (
    <>
      <Navbar />
      <div className="upload-background">
        <div className="container d-flex flex-column justify-content-center align-items-center mt-5">
          <div className="card p-4 shadow" style={{ width: "800px" }}>
            <h2 className="text-center mb-4">Upload File or Enter YouTube Link</h2>
            <form onSubmit={handleSubmit}>
              {/* File Upload Input */}
              <div className="mb-3">
                <Box
                  sx={{
                    maxWidth: "100%",
                    padding: "20px",
                    border: "1px solid gray",
                  }}
                >
                  <input
                    className="form-control"
                    onChange={handleFileChange}
                    type="file"
                    accept="video/*"
                  />
                </Box>
              </div>
    <div className="text-center text-danger">OR</div>
              {/* YouTube Link Input */}
              <div className="mb-3 mt-3 ">
                <input
                  className="form-control"
                  type="url"
                  placeholder="Enter YouTube video link"
                  value={youtubeLink}
                  onChange={handleYouTubeLinkChange}
                />
              </div>

              {/* Submit Button */}
              <Button
                type="submit"
                className="w-100"
                variant="contained"
                style={{ background: "green", color: "white" }}
                disabled={loading}
              >
                {loading ? (
                  <CircularProgress size={24} style={{ color: "white" }} />
                ) : (
                  "Submit"
                )}
              </Button>
            </form>

            {/* Video Preview */}
            {videoUrl && (
              <div className="mt-4">
                <h4>Video Preview</h4>
                {youtubeLink ? (
                  <iframe
                    width="100%"
                    height="315"
                    src={videoUrl}
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  ></iframe>
                ) : (
                  <video
                    controls
                    width="100%"
                    style={{ border: "1px solid black", marginTop: "10px" }}
                  >
                    <source src={videoUrl} type={file?.type} />
                    Your browser does not support the video tag.
                  </video>
                )}
              </div>
            )}

            {/* Display response data if available */}
            {response && (
  <div className="response mt-4">
    <h4 className="text-center mb-3">Prediction Summary</h4>

    {/* Final Percentages */}
    <Box display="flex" justifyContent="space-around" flexWrap="wrap" gap={2}>
      {response.finalStatements.map((item, index) => (
        <div
          key={index}
          className="card p-3"
          style={{ minWidth: "150px", textAlign: "center", flex: "1 1 30%" }}
        >
          <h5>{item.label}</h5>
          <p style={{ fontSize: "18px", fontWeight: "bold" }}>{item.percentage}%</p>
        </div>
      ))}
    </Box>

    {/* Predicted Statements */}
    <h5 className="mt-4">Predicted Statements</h5>
    {response.predicted_results.map(([sentence, label], index) => (
      <div
        key={index}
        className="card p-3 mt-2"
        style={{
          borderLeft: `6px solid ${
            label === "TRUE" ? "green" : label === "FALSE" ? "red" : "orange"
          }`,
        }}
      >
        <p style={{ margin: 0 }}>{sentence}</p>
        <small className="text-muted">Label: {label}</small>
      </div>
    ))}
  </div>
)}

          </div>
        </div>
      </div>
    </>
  );
}

export default FileUpload;
